 import 'package:flutter/material.dart';

void main(){
  runApp(MaterialApp(
    theme: ThemeData.dark(),
    home: Scaffold(appBar: AppBar(
      backgroundColor: Colors.black,
    
      leading: Image.asset("asset/ted.png"), 
              title: const Text(
                "TEDtalk",
                style:
                    TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
              ),
              centerTitle: true,
              actions: const [
                Icon(Icons.search),
                SizedBox(
                  width: 20,
                ),
                Icon(Icons.video_call),
                SizedBox(width: 20),
                Icon(Icons.add)
              ],),
              body: 
              Column(
              //mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children:[ 
              SizedBox(height: 20,),

                Stack(
                children: [ Container(
                  height: 150,
                  width: 350,
                  decoration: BoxDecoration(color: const Color.fromARGB(255, 199, 21, 21)),
                  child: Image.asset("asset/ted1.jpg")
                ),
                Positioned(
                  left: 8,
                  bottom: 8,
                  child: Container(padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(color: Colors.black.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text("ted takl session one",
                  textAlign: TextAlign.justify,
                  style: TextStyle(fontSize: 18,
                  
                  color: Colors.white),),),
                )
                ],
              ),
              SizedBox(height: 20,),
              Stack(
                children: [ Container(
                  height: 150,
                  width: 350,
                  decoration: BoxDecoration(color: const Color.fromARGB(255, 199, 21, 21)),
                
                  child: Image.asset("asset/ted2.jpeg")
                ),
                Positioned(
                  left: 8,
                  bottom: 8,
                  child: Container(padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(color: Colors.black.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text("ted talk session two",
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 18,
                  
                  color: Colors.white),),),
                )
                ],
              ),
              SizedBox(height: 20,),

              Stack(
                children: [ Container(
                  height: 150,
                  width: 350,
                  decoration: BoxDecoration(color: const Color.fromARGB(255, 199, 21, 21)),
                  child: Image.asset("asset/ted3.jpeg")
                ),
                Positioned(
                  left: 8,
                  bottom: 8,
                  child: Container(padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(color: Colors.black.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text("ted takl session three",
                  style: TextStyle(fontSize: 18,
                  
                  color: Colors.white),),),
                )
                ],
              )
              ],
            
                  
                ),
                 
      
              ),
              
              ),
              );
  //             ),
  // ));
}