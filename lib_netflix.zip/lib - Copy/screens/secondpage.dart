import 'package:flutter/material.dart';

class COUNTER extends StatefulWidget {
  const COUNTER({super.key});

  @override
  State<COUNTER> createState() => _COUNTERState();
}

class _COUNTERState extends State<COUNTER> {
  int count = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
    
      floatingActionButton: FloatingActionButton(onPressed: () {
        count++;
        print("this is value of count $count");
        setState(() {
          
        });
        
      },
      child: const Text("ADD"),),

      
        // (onPressed: (){}, child: const Text("increment counter")),
      
        
        
      body: Container(
        // width: 300,
        width: MediaQuery.of(context).size.width,
        color: Colors.pink,
        child:   Column(
          mainAxisAlignment: MainAxisAlignment.center,
        children: [const Text("this is the count",
        style: TextStyle(fontSize: 50),),
        
        
        Text("COUNT: ${count.toString()}"), 
        IconButton(onPressed: () {
        count--;
        setState(() {});
      },
      icon: const Icon(Icons.remove),
      ),],
      )),
    );
  }
}