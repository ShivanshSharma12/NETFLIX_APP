import 'package:flutter/material.dart';
import 'package:newday/screens/coming.dart';
import 'package:newday/screens/download.dart';
import 'package:newday/screens/homepage.dart';
import 'package:newday/screens/more.dart';
import 'package:newday/screens/search.dart';

class NavBar extends StatefulWidget {
  const NavBar({super.key});

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int _currentIndex = 0;
 final List  screens = [
      home(),
      Search(), 
      DOWNLOADS(),
      More(),
      ComingSoon(),
      
      ];
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
         backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          leading: Image.asset("asset/nflogo.png"),
        actions:   [
          // OutlinedButton(
            
          //   onPressed: (){}, child:  Text("TV Shows",
          //   style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: Colors.white)),
          //   ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            // padding: EdgeInsets.only(right:10, left: 10),
            child: GestureDetector(onTap: () {
              print("tv show is called");
            },
              child: Text("TV Shows",
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          Padding(padding: EdgeInsets.all(10.0),
            child: GestureDetector(
              onTap: () {print("movie is called");},
              child: Text("Movies",
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          Padding(padding: EdgeInsets.all(10.0),
            child: GestureDetector(
              onTap: () {
                
              },
              child: Text("My List",
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),
            ),
          ),
        ],),
        // bottomNavigationBar: BottomNavigationBar
        // (currentIndex: _currentIndex,
        // onTap: (index) {
        //   _currentIndex=index;
        //   setState(() {
            
        //   });
        // },
  //       body: screens[_currentIndex],
  //       bottomNavigationBar: BottomNavigationBar(items: const [  
  //         BottomNavigationBarItem(label: "HOME" ,icon: Icon(Icons.home)),
  //       BottomNavigationBarItem(label: "Search" ,icon: Icon(Icons.search)),
  //       BottomNavigationBarItem(label: "Coming soon" ,icon: Icon(Icons.live_tv)),],

  //       onTap: ((value) {
  //         setState(() {
  //           _currentIndex = value;
  //         });
          
  //       },
        
  //       unselectedItemColor: Colors.grey,
  //       selectedItemColor: Colors.red,
  //       showUnselectedLabels: false,
  //       showSelectedLabels: false,
  //       iconSize: 20,

  //       ))));
  // }
     

  body: screens[_currentIndex],
        bottomNavigationBar: BottomNavigationBar(
            currentIndex: _currentIndex,
            type: BottomNavigationBarType.fixed,
            onTap: (value) {
              setState(() {
                _currentIndex = value;
              });
            },
            backgroundColor: Colors.black,
            selectedItemColor: Colors.white,
            unselectedItemColor: Colors.white.withOpacity(.60),
            selectedFontSize: 13,
            unselectedFontSize: 10,
            items: const [
              BottomNavigationBarItem(label: "Home", icon: Icon(Icons.home)),
              BottomNavigationBarItem(
                  label: "Search", icon: Icon(Icons.search)),
              BottomNavigationBarItem(
                  label: "Downloads", icon: Icon(Icons.download)),
              BottomNavigationBarItem(label: "List", icon: Icon(Icons.menu)),
              BottomNavigationBarItem(
                  label: "Coming Soon", icon: Icon(Icons.tv)),
            ]),
      //   onTap: ((value) {
      //     setState(() {
      //       _currentIndex = value;
      //     });
          
      //   },
        
      //   unselectedItemColor: Colors.grey,
      //   selectedItemColor: Colors.red,
      //   showUnselectedLabels: false,
      //   showSelectedLabels: false,
      //   iconSize: 20,items: const [
      //     BottomNavigationBarItem(label: "HOME" ,icon: Icon(Icons.home)),
      //   BottomNavigationBarItem(label: "Search" ,icon: Icon(Icons.search)),
      //   BottomNavigationBarItem(label: "Coming soon" ,icon: Icon(Icons.live_tv)),
      //   // BottomNavigationBarItem(label: "Download" ,icon: Icon(Icons.download)),
      //   // BottomNavigationBarItem(label: "More" ,icon: Icon(Icons.more_vert)),
      //   ]),
      // ),
    ));
  }
}