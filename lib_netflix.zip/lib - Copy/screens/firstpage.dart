import 'package:flutter/material.dart';
import 'package:newday/shared/widgets/button.dart';
import 'package:newday/shared/widgets/itemcontainer.dart';

class Firstpage extends StatelessWidget {
  const Firstpage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(
              backgroundColor: Colors.black,
              // leading: const Icon(Icons.battery_1_bar),
              leading: const Row(
                children: [
                  SizedBox(
                    width: 20,
                  ),
                  Icon(Icons.notification_add),
                  // Icon(Icons.search),
                ],
              ),
              title: const Text(
                "YouTube",
                style:
                    TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
              ),
              centerTitle: true,
              actions: const [
                Icon(Icons.search),
                SizedBox(
                  width: 20,
                ),
                Icon(Icons.video_call),
                SizedBox(width: 20),
                Icon(Icons.add)
              ],
            ),
             body:  Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    itemcontainer(containercolor: Colors.red, textdata:"RED",),
                    itemcontainer(containercolor: Colors.orange, textdata: "orange",),
                    itemcontainer(containercolor: Colors.blue, textdata: "blue",),
                    
                  ],
                ),
                Row(
                  children: [
                    button(buttonicon: Icons.add),
                    button(buttonicon: Icons.remove),
                  ],
                )
              ],
             ),
           
           
            // body: const Center(child: Text('HELLO THIS IS FLUTTER')),
            // body: Column(
            //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            //   children: [
            //     Row(
            //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,

            //       children: [
            //         Container(
            //           height: 100,
            //           width: 100,
            //           color: Colors.red,
            //         ),
            //         const SizedBox(
            //           width: 20,
            //         ),
            //         Container(
            //           height: 100,
            //           width: 100,
            //           color: Colors.yellow,
            //         ),
            //         const SizedBox(
            //           width: 20,
            //         ),
            //         Container(
            //           height: 100,
            //           width: 100,
            //           color: Colors.blue,
            //         )
            //       ],
            //     ),
            //     Row(
            //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,

            //       children: [
            //         newcont(containercolor: Colors.yellow),
            //         const SizedBox(
            //           width: 20,
            //         ),
            //         newcont(containercolor: Colors.black),
            //         Container(
            //           height: 100,
            //           width: 100,
            //           decoration: BoxDecoration(
            //           color: Colors.yellow,
            //           borderRadius: BorderRadius.all(Radius.circular(20))),

            //           ),
                  
                    
            //         const SizedBox(
            //           width: 20,
            //         ),
            //         itemcontainer(containercolor: Colors.pink),

            //         // Container(
            //         //   height: 100,
            //         //   width: 100,
            //         //   decoration: BoxDecoration(
            //         //   color: Colors.blue,
            //         //   borderRadius: BorderRadius.all(Radius.circular(20))),
            //         // )
            //       ],
            //     ),
            //     Row(
            //       mainAxisAlignment: MainAxisAlignment.center,
            //       children: [
            //         Container(
            //           height: 100,
            //           width: 350,
            //           decoration: BoxDecoration(
            //           color: Colors.orange,
            //           borderRadius: BorderRadius.all(Radius.circular(20)),
            //           ),
            //           child: Padding(padding: const EdgeInsets.all(8.0),
            //           child: Row(
            //             mainAxisSize: MainAxisSize.min,
            //             mainAxisAlignment: MainAxisAlignment.start,
            //             children: [
            //               Image.asset("asset/banana.png"),
            //               SizedBox(width: 15,),
            //               Text("this is banana",
            //               style: TextStyle(color: Colors.black,
            //               fontSize: 15),)
            //             ],
            //           ),) ,
            //           // child: Image.asset("asset/banana.png"),
                      
            //         )

            //       ],

            //     ),

               

            //     Row(
            //       mainAxisAlignment: MainAxisAlignment.center,
            //       children: [
            //         Container(
            //           height: 100,
            //           width: 350,
            //           decoration: BoxDecoration(
            //           color: Colors.pink,
            //           borderRadius: BorderRadius.all(Radius.circular(20)),
            //           ),
            //           child: Padding(padding: const EdgeInsets.all(8.0),
            //           child: Row(
            //             mainAxisSize: MainAxisSize.min,
            //             mainAxisAlignment: MainAxisAlignment.start,
            //             children: [
            //               Image.asset("asset/kiwi.png"),
            //               SizedBox(width: 15,),
            //               Text("this is kiwi",
            //               style: TextStyle(color: Colors.black,
            //               fontSize: 15),)
            //             ],
            //           ),) ,
            //           // child: Image.asset("asset/banana.png"),
                      
            //         )
            //       ],

            //     ),
            //     const Row(),
            //     const Row()
            //   ],
            // )
             );

    
  }
}