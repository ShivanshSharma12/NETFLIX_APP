import 'package:flutter/material.dart';
// import 'package:newday/screens/coming.dart';
// import 'package:newday/screens/download.dart';
// import 'package:newday/screens/more.dart';
// import 'package:newday/screens/search.dart';
import 'package:newday/shared/widgets/My_list.dart';
import 'package:newday/shared/widgets/nf_stack.dart';
import 'package:newday/shared/widgets/originals.dart';
import 'package:newday/shared/widgets/preview.dart';

// class home extends StatefulWidget {
//   const home({super.key});

//   @override
//   State<home> createState() => _homeState();
// }

// class _homeState extends State<home> {
//   int _currentIndex = 0;
//   void changeTab(int index){
//     setState(()=> _currentIndex = index);
//   }
//   @override
//   Widget build(BuildContext context) {
//     final List = [
//       home(),
//       MorePage(), 
//       DownloadPage(),
//       ComingPage(),
//       SearchPage(),
      
//       ];
//     return Scaffold(
//       body: IndexedStack(
//         index: _currentIndex,
//         children: List,
//       ),
//       bottomNavigationBar: BottomNavigationBar(
//         currentIndex: _currentIndex,
//         onTap: (index) => changeTab(index),
//         type: BottomNavigationBarType.fixed,
//         unselectedItemColor: Colors.grey,
//         selectedItemColor: Colors.red,
//         showUnselectedLabels: false,
//         showSelectedLabels: false,
//         iconSize: 20,
//         items: const [
//           BottomNavigationBarItem(
//             icon: Icon(Icons.home),
//             label: 'HomePage',
//           ),
//           BottomNavigationBarItem(
//             icon: Icon(Icons.more_vert),
//             label: 'MorePage',
//           ),
//           BottomNavigationBarItem(
//             icon: Icon(Icons.download),
//             label: 'DownloadPage',
//           ),
//         ],
//       ),
//     );
//   }
// }
    class home extends StatefulWidget {
  const home({super.key});

  @override
  State<home> createState() => _homeState();
}

class _homeState extends State<home> {
   
  @override
  Widget build(BuildContext context) {
    
      return SafeArea(
        child: Scaffold( 
      //     body: IndexedStack(
      //   index: _currentIndex,
      //   children: List,
      // ),
          
         backgroundColor: Colors.black,
        // appBar: AppBar(
        //   backgroundColor: Colors.transparent,
        //   leading: Image.asset("asset/nflogo.png"),
        // actions:   [
          // OutlinedButton(
            
          //   onPressed: (){}, child:  Text("TV Shows",
          //   style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold, color: Colors.white)),
          //   ),
        //   Padding(
        //     padding: const EdgeInsets.all(10.0),
        //     // padding: EdgeInsets.only(right:10, left: 10),
        //     child: GestureDetector(onTap: () {
        //       print("tv show is called");
        //     },
        //       child: Text("TV Shows",
        //       style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
        //       ),
        //     ),
        //   ),
        //   Padding(padding: EdgeInsets.all(10.0),
        //     child: GestureDetector(
        //       onTap: () {print("movie is called");},
        //       child: Text("Movies",
        //       style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
        //       ),
        //     ),
        //   ),
        //   Padding(padding: EdgeInsets.all(10.0),
        //     child: GestureDetector(
        //       onTap: () {
                
        //       },
        //       child: Text("My List",
        //       style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),
        //     ),
        //   ),
        // ],),
        // bottomNavigationBar: BottomNavigationBar
        // (currentIndex: _currentIndex,
        // onTap: (index) {
        //   _currentIndex=index;
        //   setState(() {
            
        //   });
        // },
        // type: BottomNavigationBarType.fixed,
        // unselectedItemColor: Colors.grey,
        // selectedItemColor: Colors.red,
        // showUnselectedLabels: false,
        // showSelectedLabels: false,
        // iconSize: 20,items: const [
        //   BottomNavigationBarItem(label: "HOME" ,icon: Icon(Icons.home)),
        // BottomNavigationBarItem(label: "Search" ,icon: Icon(Icons.search)),
        // BottomNavigationBarItem(label: "Coming soon" ,icon: Icon(Icons.live_tv)),
        // // BottomNavigationBarItem(label: "Download" ,icon: Icon(Icons.download)),
        // // BottomNavigationBarItem(label: "More" ,icon: Icon(Icons.more_vert)),
        // ]),
        

        body: SingleChildScrollView(
          child: Container(
            width: double.infinity,
          // height: double.infinity,
          child: const Column(
            children: [NFSTACK(), PREVIEW(), LIST(), ORIGINALS()],
          ),
          
          ),
        ),
      ),
    );
  }
}