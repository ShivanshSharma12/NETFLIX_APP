//  import 'package:flutter/material.dart';
// // void main() {
// //   runApp(MaterialApp(
// //     home: Scaffold(
// //         appBar: AppBar(
// //           backgroundColor: const Color.fromARGB(255, 3, 116, 47),
// //           leading: Image.asset('assets/logo.png'),
// //           title: const Text(
// //             'Fruitopia',
// //           ),
// //           actions: const [
// //             Icon(Icons.search_sharp),
// //             SizedBox(
// //               width: 20,
// //             ),
// //             SizedBox(
// //               width: 20,
// //             ),
// //             Icon(Icons.add_shopping_cart_sharp),
// //             SizedBox(
// //               width: 20,
// //             ),
// //             Icon(Icons.circle_notifications_sharp),
// //             SizedBox(
// //               width: 20,
// //             ),
// //             Icon(Icons.account_circle_sharp),
// //             SizedBox(
// //               width: 20,
// //             ),
// //           ],
// //         ),
// //         body: Center(
// //           child: Column(
// //             children:  [
// //               const SizedBox( 
// //                 height: 40,
// //               ),
// //               Container(
// //                 width: 150,
// //                 height: 100,
// //                 decoration: const BoxDecoration(
// //                     color: Color.fromARGB(255, 0, 4, 8),
// //                     borderRadius: BorderRadius.all(Radius.circular(50))),
// //                  child: Image.asset('assets/kiwi.jpeg'),
// //               ),

// //               const SizedBox( 
// //                 height: 30,
// //               ),
// //               const Text(
// //                 "Buy a pack of fresh Kiwi only @299",
// //                 style: TextStyle(fontSize: 20),
// //               ),
// //               const SizedBox( 
// //                 height: 40,
// //               ),

// //               Container(
// //                 width: 150,
// //                 height: 100,
// //                 decoration: const BoxDecoration(
// //                     color: Color.fromARGB(255, 0, 4, 7),
// //                     borderRadius: BorderRadius.all(Radius.circular(50))),
// //                 child: Image.asset('assets/cherry.jpeg'),
// //               ),

// //               const SizedBox( 
// //                 height: 30,
// //               ),
// //               const Text(
// //                 "Buy a pack of fresh cherries only @699",
// //                 style: TextStyle(fontSize: 20),
// //               ),

// //               const SizedBox( 
// //                 height: 40,
// //               ),
// //               Container(
// //                 width: 150,
// //                 height: 100,
// //                 decoration: const BoxDecoration(
// //                     color: Color.fromARGB(255, 0, 4, 7),
// //                     borderRadius: BorderRadius.all(Radius.circular(50))),
// //                 child: Image.asset('assets/strawberry.jpeg'),
// //               ),

// //               const SizedBox( 
// //                 height: 30,
// //               ),
              
// //               const Text(
// //                 "Buy a pack of fresh strawberries only @499",
// //                 style: TextStyle(fontSize: 20),
// //               ),
// //             ],
// //           ),
// //         )),
// //   ));
// // }
// void main() {
//   runApp(
//     MaterialApp(
//         // theme: ThemeData.dark(),
//         home: Scaffold(
//           // floatingActionButton: FloatingActionButton(onPressed: (){
//           //     print("clicked");
//           //   },
//           //   child: const Icon(Icons.chat),),
//           //   // floatingActionButtonLocation: FloatingActionButtonLocation.startTop,
//             appBar: AppBar(
//               // leading: const Icon(Icons.battery_1_bar),
//               leading: const Row(
//                 children: [
//                   SizedBox(
//                     width: 20,
//                   ),
//                   Icon(Icons.search),
//                 ],
//               ),
//               title: const Text(
//                 "FRESH-FRUITS",
//                 style:
//                     TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
                    
//               ),
//               centerTitle: true,
//               actions: const [
//                 Icon(Icons.search),
//                 SizedBox(
//                   width: 20,
//                 ),
//                 Icon(Icons.video_call),
//                 Icon(Icons.add)
//               ],
//             ),
//             // body: const Center(child: Text('HELLO THIS IS FLUTTER')),
//             body:  Column(
              
//         Container(
//           width: 150,
//           height: 150
            
//               child: [
//                children: [
//                  Row(
//                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   children: [
//                 Container(
//                        height: 150,
//                       width: 100,)
//                   ]    
//                ]   
//             //         //   decoration: BoxDecoration(
//                     //       color: Colors.red,
//                           border: Border.all(width: 5),
//                           // border: Border.all(width: 20),
//                           borderRadius:
//                               const BorderRadius.all(Radius.circular(20))),
//                                child: Column(
//                                 children: [Image.asset("asset/banana.png"),
//                                 // const BorderRadius.all(Radius.circular(20)),
//                                 const Text(
//                                   "Banana",
//                                   style: TextStyle(
//                                     color: Colors.white,
//                                     fontWeight: FontWeight.bold
//                                   ),
//                                 )
                              
//                               ]),

//                     ),
                    
//                     Container(
//                       height: 150,
//                       width: 100,
                      
//                       decoration: BoxDecoration(
//                           color: Colors.yellow,
//                           border: Border.all(width: 5),
//                           // border: Border.all(width: 20),
//                           borderRadius:
//                               const BorderRadius.all(Radius.circular(20))),
//                                child: Column(
//                                 children: [Image.asset("asset/kiwi.png"),
//                                 // const BorderRadius.all(Radius.circular(20)),
//                                 const Text(
//                                   "Kiwi",
//                                   style: TextStyle(
//                                     color: Colors.white,
//                                     fontWeight: FontWeight.bold
//                                   ),
//                                 )
                              
//                               ]),

//                     ),
                    
//                     Container(
//                       height: 150,
//                       width: 100,
//                       decoration: BoxDecoration(
//                           color: Colors.blue,
//                           border: Border.all(width: 5),
//                           // border: Border.all(width: 20),
//                           borderRadius:
//                               const BorderRadius.all(Radius.circular(20))),
//                               // child: Image.asset("asset/apple.jpg"),
//                               child: Column(
//                                 children: [Image.asset("asset/apple.jpg"),
//                                 // const BorderRadius.all(Radius.circular(20)),
//                                 const Text(
//                                   "orange",
//                                   style: TextStyle(
//                                     color: Colors.white,
//                                     fontWeight: FontWeight.bold
//                                   ),
//                                 )
                              
//                               ]),
//                     )
//                   ],
//                 ),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   children: [
//                     Container(
//                       height: 150,
//                       width: 100,
//                       decoration: BoxDecoration(
//                           color: Colors.red,
//                           border: Border.all(width: 5),
//                           // border: Border.all(width: 20),
//                           borderRadius:
//                               const BorderRadius.all(Radius.circular(20))),
//                     ),
                    
//                     Container(
//                       height: 150,
//                       width: 100,
//                       decoration: BoxDecoration(
//                           color: Colors.yellow,
//                           border: Border.all(width: 5),
//                           // border: Border.all(width: 20),
//                           borderRadius:
//                               const BorderRadius.all(Radius.circular(20))),
//                     ),
                    
//                     // Container(
//                     //   height: 150,
//                     //   width: 100,
                      
//                     //   decoration: BoxDecoration(
//                     //       color: Colors.blue,
//                     //       border: Border.all(width: 5),
//                     //       // border: Border.all(width: 20),
//                     //       borderRadius:
//                     //           const BorderRadius.all(Radius.circular(20))),
//                     // )
//                   ],
//                 ),
//                 const Row(),
//                 const Row()
//               ],
            
//             )));
  
// }




