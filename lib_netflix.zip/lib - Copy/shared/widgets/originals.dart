import 'package:flutter/material.dart';

class ORIGINALS extends StatelessWidget {
  const ORIGINALS({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment:CrossAxisAlignment.start,
      children: [Text("Netflix originals", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),),
      SizedBox(height: 300, width: double.infinity, child: ListView(
        padding: const EdgeInsets.all(10),
        scrollDirection: Axis.horizontal,
        children: [
          Container(
            height: 300,
            width: 200,
            child: Image.asset("asset/sintel.jpg"),
          ),
          Container(
            height: 300,
            width: 200,
            child: Image.asset("asset/bollywood9.jpg"),
          ),
          Container(
            height: 300,
            width: 200,
            child: Image.asset("asset/stranger_things.jpg"),
          ),
          Container(
            height: 300,
            width: 200,
            child: Image.asset("asset/bollywood7.jpg"),
          ),
          Container(
            height: 300,
            width: 200,
            child: Image.asset("asset/witcher.jpg"),
          ),
          Container(
            height: 300,
            width: 200,
            child: Image.asset("asset/sintel.jpg"),
          ),
        ],
      ),)
      ],
    );
  }
}