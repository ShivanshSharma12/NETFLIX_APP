import 'package:flutter/material.dart';

class itemcontainer extends StatelessWidget {
  Color containercolor;
  String textdata;
   itemcontainer({super.key, required this.containercolor, required this.textdata});

  @override
  Widget build(BuildContext context) {
    return Container(
       height: 100,
                    width: 100,
                    decoration:  BoxDecoration(
                        color: containercolor,
                        // border: Border.all(width: 10),
                        // border: Border.all(width: 20),
                        borderRadius:
                            const BorderRadius.all(Radius.circular(20))),
                            child:  Center(
                              child: Text(textdata,
                              style: TextStyle(color: Colors.white,),
                            ),
                  
    ),
    );
  }
}