import 'package:flutter/material.dart';

class button extends StatelessWidget {
  IconData buttonicon;
 button({super.key, required this.buttonicon});


  @override
  Widget build(BuildContext context) {
    return  IconButton(onPressed: (){}, icon: Icon(buttonicon));
       
      
      
    
  }
}