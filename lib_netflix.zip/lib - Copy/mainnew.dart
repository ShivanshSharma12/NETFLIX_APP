import 'package:flutter/material.dart';
import 'package:newday/screens/bottomnav.dart';
// import 'package:newday/screens/homepage.dart';s

void main(){
  runApp(MaterialApp(
    home: NavBar(
    
    ),
    ));
}